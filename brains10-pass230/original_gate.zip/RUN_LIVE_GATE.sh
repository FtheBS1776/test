#!/bin/sh
set -u
python3 PREFLIGHT.py || exit $?
rm -rf PASS230_LIVE_RESULT
mkdir PASS230_LIVE_RESULT
python3 live_gate.py > PASS230_LIVE_RESULT/TEST_RESULTS.txt 2>&1
rc=$?
python3 seal_result.py "$rc"
exit "$rc"
