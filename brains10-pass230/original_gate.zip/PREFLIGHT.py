import os, shutil, subprocess, sys

required = ("ETCDCTL_ENDPOINTS", "BRAINS10_ETCD_NAMESPACE")
missing = [x for x in required if not os.environ.get(x, "").strip()]
if missing:
    print("PREFLIGHT_HOLD missing:", ",".join(missing))
    raise SystemExit(2)

ns = os.environ["BRAINS10_ETCD_NAMESPACE"].strip()
if ns in ("/", "*"):
    print("PREFLIGHT_HOLD unsafe namespace")
    raise SystemExit(2)

exe = shutil.which("etcdctl")
if not exe:
    print("PREFLIGHT_HOLD etcdctl not found")
    raise SystemExit(2)

p = subprocess.run([exe, "version"], capture_output=True, text=True)
if p.returncode:
    print("PREFLIGHT_HOLD etcdctl version failed")
    raise SystemExit(2)

print("PREFLIGHT_PASS")
print(p.stdout.strip())
