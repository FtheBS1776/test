# Scope and Nonclaims

The gate observes:
- a normal Range path and a separately requested serializable path;
- exact-value Compare/Txn conflict behavior;
- atomic successor + stable transaction-receipt writes;
- replay/retry observation.

It does not establish:
- trustworthy provisioning of endpoint/CA/client identity;
- whole-world compromise/rollback resistance;
- physical durability;
- root-key custody/recovery;
- production readiness.

Missing prerequisites are HOLD, never PASS.
