import sys, hashlib, json
from pathlib import Path

rc = int(sys.argv[1])
d = Path("PASS230_LIVE_RESULT")
b = (d / "TEST_RESULTS.txt").read_bytes()
m = {
    "gate": "BRAINS10_PASS230",
    "execution_returncode": rc,
    "test_results_sha256": hashlib.sha256(b).hexdigest(),
    "disposition": "EXECUTION_COMPLETE" if rc == 0 else ("HOLD" if rc == 2 else "DEFECT_OR_INDETERMINATE"),
    "note": "Evidence only; does not establish provider trust or promotion."
}
(d / "RESULT_MANIFEST.json").write_text(json.dumps(m, indent=2, sort_keys=True) + "\n")
print(json.dumps(m, sort_keys=True))
