import os, subprocess, json, sys, base64

EP = os.environ["ETCDCTL_ENDPOINTS"]
NS = os.environ["BRAINS10_ETCD_NAMESPACE"].rstrip("/")
HEAD = NS + "/authority/head"
TX = NS + "/authority/tx/pass230"

def ctl(args, stdin=None):
    env = os.environ.copy()
    env["ETCDCTL_API"] = "3"
    return subprocess.run(
        ["etcdctl", "--endpoints", EP] + args,
        input=stdin, text=True, capture_output=True, env=env
    )

def must(p, label):
    if p.returncode:
        print("HOLD", label, p.stderr.strip())
        raise SystemExit(2)

def get(key, serializable=False):
    args = ["get", key, "-w", "json"]
    if serializable:
        args.append("--consistency=s")
    p = ctl(args)
    must(p, "get")
    return json.loads(p.stdout or "{}")

def value(obj):
    kvs = obj.get("kvs") or []
    if not kvs:
        return None
    return base64.b64decode(kvs[0]["value"]).decode()

initial = '{"authority_config":"PASS230","digest":"PASS230-G0","generation":0}'
successor = '{"authority_config":"PASS230","digest":"PASS230-G1","generation":1}'

p = ctl(["put", HEAD, initial])
must(p, "put-initial")

linear = get(HEAD, False)
serial = get(HEAD, True)
print("LINEARIZABLE_RANGE_OBSERVED", value(linear) == initial)
print("SERIALIZABLE_PATH_OBSERVED", value(serial) == initial)

txn_script = (
    'compare\n'
    'value("' + HEAD + '") = "' + initial.replace('"', '\\\"') + '"\n'
    'success\n'
    'put ' + HEAD + " '" + successor + "'\n"
    'put ' + TX + ' PASS230-TX-1\n'
    'failure\n'
    'get ' + HEAD + '\n'
)

p = ctl(["txn"], stdin=txn_script)
must(p, "txn")
print("TXN1", p.stdout.strip())

after = get(HEAD)
receipt = get(TX)

p2 = ctl(["txn"], stdin=txn_script)
must(p2, "txn-replay")
print("TXN_REPLAY", p2.stdout.strip())

after2 = get(HEAD)
receipt2 = get(TX)

checks = {
    "head_is_successor": value(after) == successor,
    "receipt_present": value(receipt) == "PASS230-TX-1",
    "replay_head_unchanged": value(after2) == successor,
    "replay_receipt_unchanged": value(receipt2) == "PASS230-TX-1",
}
print("CHECKS", json.dumps(checks, sort_keys=True))

if not all(checks.values()):
    print("LIVE_GATE_DEFECT_OR_INDETERMINATE")
    raise SystemExit(1)

print("LIVE_GATE_OBSERVATIONS_PASS")
