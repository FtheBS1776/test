# Pass 230 — Live etcd Conformance Execution Gate — NONCLAIM

Purpose: collect evidence for the Pass-225 LIVE_PROVIDER_CONFORMANCE_HOLD against a real,
independently provisioned etcd environment.

This package contains no etcd server, trust anchor, credentials, or mock provider.

Required external inputs:
- ETCDCTL_ENDPOINTS
- BRAINS10_ETCD_NAMESPACE (dedicated disposable prefix)
- etcdctl
- ETCDCTL_CACERT / ETCDCTL_CERT / ETCDCTL_KEY when required by the provisioned environment

Sequence:
1. Read SCOPE_AND_NONCLAIMS.md.
2. Run `python3 PREFLIGHT.py`.
3. Only if PREFLIGHT_PASS, run `bash RUN_LIVE_GATE.sh`.
4. Return PASS230_LIVE_RESULT for later adjudication.

Execution does not promote or freeze anything.
