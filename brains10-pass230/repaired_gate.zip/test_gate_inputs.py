import unittest
import pathlib
import shutil
import subprocess
import tempfile

from gate_inputs import build_init_script, build_txn_script, child_environment, normalize_namespace, txn_outcome


class GateInputTests(unittest.TestCase):
    def test_existing_result_directory_is_preserved(self):
        with tempfile.TemporaryDirectory(prefix='pass230-result-preservation-') as tmp:
            root = pathlib.Path(tmp)
            runner = root / 'RUN_LIVE_GATE.sh'
            shutil.copyfile(pathlib.Path(__file__).with_name('RUN_LIVE_GATE.sh'), runner)
            output = root / 'PASS230_LIVE_RESULT'
            output.mkdir()
            sentinel = output / 'keep.txt'
            sentinel.write_text('preserve')
            result = subprocess.run(['sh', str(runner)], capture_output=True, text=True, timeout=5)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(sentinel.read_text(), 'preserve')
            self.assertIn('HOLD result path already exists', result.stdout)

    def test_namespace_accepts_exact_safe_prefix(self):
        self.assertEqual(normalize_namespace("/brains10/pass230"), "/brains10/pass230")

    def test_namespace_rejects_root_and_slash_only_aliases(self):
        for value in ("/", "///", "////"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                normalize_namespace(value)

    def test_namespace_rejects_dsl_injection_and_ambiguous_segments(self):
        for value in (
            "/safe\nname",
            '/safe"name',
            "/safe//child",
            "/safe/../outside",
            "/safe/.",
            "/safe/child ",
        ):
            with self.subTest(value=value), self.assertRaises(ValueError):
                normalize_namespace(value)

    def test_txn_uses_documented_blank_line_sections_without_prompt_labels(self):
        script = build_txn_script(
            "/safe/authority/head",
            "/safe/authority/tx/pass230",
            '{"digest":"G0"}',
            '{"digest":"G1"}',
            "PASS230-TX-1",
        )
        sections = script.split("\n\n")
        self.assertEqual(len(sections), 4)
        self.assertEqual(sections[-1], "")
        self.assertTrue(sections[0].startswith('value("/safe/authority/head") = '))
        self.assertTrue(sections[1].startswith('put "/safe/authority/head" '))
        self.assertTrue(sections[2].startswith('get "/safe/authority/head"'))
        self.assertNotIn("compare\n", script)
        self.assertNotIn("success\n", script)
        self.assertNotIn("failure\n", script)

    def test_txn_outcome_requires_explicit_success_or_failure(self):
        self.assertEqual(txn_outcome("SUCCESS\n\nOK\n"), "SUCCESS")
        self.assertEqual(txn_outcome("FAILURE\n\nOK\n"), "FAILURE")
        self.assertIsNone(txn_outcome("OK\n"))

    def test_status_is_first_nonempty_response_line(self):
        self.assertEqual(txn_outcome("\nFAILURE\n\nOK\n"), "FAILURE")
        self.assertIsNone(txn_outcome("OK\nSUCCESS\n"))

    def test_explicit_cli_flags_have_no_duplicate_environment_values(self):
        source = {'ETCDCTL_ENDPOINTS': 'http://unused.invalid:2379',
                  'ETCDCTL_WRITE_OUT': 'json', 'ETCDCTL_COMMAND_TIMEOUT': '9s',
                  'ETCDCTL_DIAL_TIMEOUT': '9s', 'ETCDCTL_CACERT': '/configured/ca.pem',
                  'ETCDCTL_CONSISTENCY': 's', 'ETCDCTL_PREFIX': 'true', 'ETCDCTL_REV': '4'}
        cleaned = child_environment(source)
        self.assertEqual(cleaned, {'ETCDCTL_CACERT': '/configured/ca.pem', 'ETCDCTL_API': '3'})
        self.assertIn('ETCDCTL_ENDPOINTS', source)

    def test_initialization_conditions_and_write_are_one_transaction(self):
        script = build_init_script('/safe/head', '/safe/receipt', 'initial')
        compare, success, failure, ending = script.split('\n\n')
        self.assertEqual(compare.splitlines(), ['version("/safe/head") = "0"', 'version("/safe/receipt") = "0"'])
        self.assertEqual(success, 'put "/safe/head" "initial"')
        self.assertEqual(failure.splitlines(), ['get "/safe/head"', 'get "/safe/receipt"'])
        self.assertEqual(ending, '')


if __name__ == "__main__":
    unittest.main()
