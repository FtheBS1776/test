#!/bin/sh
set -u

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 2
cd "$script_dir" || exit 2

result_dir=PASS230_LIVE_RESULT
if [ -e "$result_dir" ] || [ -L "$result_dir" ]; then
    echo "HOLD result path already exists: $result_dir"
    exit 2
fi

python3 -B PREFLIGHT.py || exit $?
if ! mkdir "$result_dir"; then
    echo "HOLD could not create result path: $result_dir"
    exit 2
fi

python3 -B live_gate.py > "$result_dir/TEST_RESULTS.txt" 2>&1
rc=$?
python3 -B seal_result.py "$rc"
seal_rc=$?
if [ "$seal_rc" -ne 0 ]; then
    echo "HOLD result sealing failed"
    exit 2
fi
exit "$rc"
