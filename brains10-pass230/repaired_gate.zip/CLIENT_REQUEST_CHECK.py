"""Local client test only: record requests, always return an error, store no state.

Requires grpcio==1.76.0 and protobuf==6.33.0 for this recorded test environment.
Descriptor subset: etcd v3.6.5 api/etcdserverpb/rpc.proto,
SHA256 c57117e8f4764667be927d862f4fb01fbf1faaf0f725bf2eecc3a523e12aacc6.
This never establishes live-provider conformance.
"""
import argparse
import base64
import concurrent.futures
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--client', required=True)
    parser.add_argument('--deps')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.deps:
        sys.path.insert(0, args.deps)
    import grpc
    import google.protobuf
    from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

    schema = descriptor_pb2.FileDescriptorProto(name='request_subset.proto', package='requestcheck', syntax='proto3')
    # Types: bytes=12, int64=3, uint32=13, bool=8, message=11.
    definitions = {
        'Range': [('key', 1, 12, None, False), ('serializable', 7, 8, None, False)],
        'Put': [('key', 1, 12, None, False), ('value', 2, 12, None, False)],
        'Compare': [('result', 1, 13, None, False), ('target', 2, 13, None, False),
                    ('key', 3, 12, None, False), ('version', 4, 3, None, False),
                    ('value', 7, 12, None, False)],
        'Op': [('request_range', 1, 11, 'Range', False), ('request_put', 2, 11, 'Put', False)],
        'Txn': [('compare', 1, 11, 'Compare', True), ('success', 2, 11, 'Op', True),
                ('failure', 3, 11, 'Op', True)],
    }
    for name, fields in definitions.items():
        message = schema.message_type.add(name=name)
        for field_name, number, field_type, nested, repeated in fields:
            field = message.field.add(name=field_name, number=number, type=field_type, label=3 if repeated else 1)
            if nested:
                field.type_name = '.requestcheck.' + nested
    pool = descriptor_pool.DescriptorPool()
    pool.Add(schema)
    classes = {n: message_factory.GetMessageClass(pool.FindMessageTypeByName('requestcheck.' + n)) for n in definitions}

    observed = []
    def recorder(method):
        def handle(raw, context):
            observed.append((method, raw))
            context.abort(grpc.StatusCode.FAILED_PRECONDITION, 'CLIENT_REQUEST_CAPTURE_ONLY')
        return grpc.unary_unary_rpc_method_handler(handle)

    server = grpc.server(concurrent.futures.ThreadPoolExecutor(max_workers=2))
    server.add_generic_rpc_handlers((grpc.method_handlers_generic_handler('etcdserverpb.KV', {
        'Txn': recorder('Txn'), 'Range': recorder('Range'),
    }),))
    port = server.add_insecure_port('127.0.0.1:0')
    if not port:
        raise RuntimeError('cannot bind local recorder')
    server.start()
    try:
        for key in list(os.environ):
            if key.startswith('ETCDCTL_'):
                del os.environ[key]
        client = pathlib.Path(args.client).resolve(strict=True)
        os.environ['PATH'] = str(client.parent) + os.pathsep + os.environ.get('PATH', '')
        selected = shutil.which('etcdctl')
        if selected is None or pathlib.Path(selected).resolve() != client:
            raise ValueError('--client must name the etcdctl executable actually selected')
        os.environ['ETCDCTL_ENDPOINTS'] = f'http://127.0.0.1:{port}'
        os.environ['ETCDCTL_WRITE_OUT'] = 'json'
        os.environ['ETCDCTL_CONSISTENCY'] = 's'
        os.environ['ETCDCTL_PREFIX'] = 'true'
        os.environ['ETCDCTL_REV'] = '4'
        os.environ['BRAINS10_ETCD_NAMESPACE'] = '/parser-only'
        import live_gate as gate
        from gate_inputs import build_init_script, build_txn_script

        initial = '{"authority_config":"PASS230","digest":"PASS230-G0","generation":0}'
        successor = '{"authority_config":"PASS230","digest":"PASS230-G1","generation":1}'
        head, receipt = gate.HEAD.encode(), gate.TX.encode()
        init_expected = classes['Txn']()
        for key in (head, receipt):
            init_expected.compare.add(key=key, target=0, result=0, version=0)
            init_expected.failure.add().request_range.key = key
        init_expected.success.add().request_put.CopyFrom(classes['Put'](key=head, value=initial.encode()))
        txn_expected = classes['Txn']()
        txn_expected.compare.add(key=head, target=3, result=0, value=initial.encode())
        for key, value in ((head, successor.encode()), (receipt, b'PASS230-TX-1')):
            txn_expected.success.add().request_put.CopyFrom(classes['Put'](key=key, value=value))
        txn_expected.failure.add().request_range.key = head

        cases = [
            ('initialization', ['txn'], build_init_script(gate.HEAD, gate.TX, initial), 'Txn', init_expected),
            ('transition', ['txn'], build_txn_script(gate.HEAD, gate.TX, initial, successor, 'PASS230-TX-1'), 'Txn', txn_expected),
            ('linearizable_request', ['get', gate.HEAD, '--consistency=l'], None, 'Range', classes['Range'](key=head, serializable=False)),
            ('serializable_request', ['get', gate.HEAD, '--consistency=s'], None, 'Range', classes['Range'](key=head, serializable=True)),
        ]
        results = []
        for name, command, stdin, method, expected in cases:
            observed.clear()
            response = gate.ctl(command, stdin=stdin, output='simple' if method == 'Txn' else 'json')
            if response.returncode == 0 or 'CLIENT_REQUEST_CAPTURE_ONLY' not in response.stderr:
                raise AssertionError((name, 'recorder error not returned', response.returncode))
            if len(observed) != 1 or observed[0][0] != method:
                raise AssertionError((name, 'unexpected RPC set'))
            raw = observed[0][1]
            decoded = classes[method].FromString(raw)
            before = decoded.SerializeToString()
            decoded.DiscardUnknownFields()
            if before != decoded.SerializeToString() or decoded != expected:
                raise AssertionError((name, 'request differs from expected contract', str(decoded)))
            results.append({'case': name, 'request_matches': True, 'request_base64': base64.b64encode(raw).decode(),
                            'client_exit': response.returncode, 'expected_test_error': 'CLIENT_REQUEST_CAPTURE_ONLY'})
        result = {'status': 'CLIENT_REQUEST_CHECK_PASS', 'scope': 'local client parsing and emitted request only',
                  'provider_conformance': 'NOT_TESTED', 'client_sha256': hashlib.sha256(client.read_bytes()).hexdigest(),
                  'client_version': subprocess.run([str(client), 'version'], capture_output=True, text=True, check=True).stdout.strip(),
                  'python': sys.version, 'grpcio': grpc.__version__, 'protobuf': google.protobuf.__version__, 'cases': results}
        pathlib.Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        print(result['status'], len(results), '/', len(cases), 'PROVIDER_CONFORMANCE_NOT_TESTED')
    finally:
        server.stop(0).wait()


if __name__ == '__main__':
    main()
