# Pass 230 — Live etcd Conformance Execution Gate — NONCLAIM

Continuation revision 2. The first repair is superseded for future use. See
CONTINUATION_REPORT.md for corrected claims, evidence, and remaining HOLDs.

Purpose: collect evidence for the Pass-225 LIVE_PROVIDER_CONFORMANCE_HOLD against a real,
independently provisioned etcd environment.

This package contains no etcd server, trust anchor, credentials, or mock provider.
Extract into a fresh directory and verify GATE_MANIFEST.json before execution.

Required external inputs:
- ETCDCTL_ENDPOINTS
- BRAINS10_ETCD_NAMESPACE (dedicated disposable prefix)
- etcdctl
- ETCDCTL_CACERT / ETCDCTL_CERT / ETCDCTL_KEY when required by the provisioned environment

Sequence:
1. Read SCOPE_AND_NONCLAIMS.md.
2. Run `python3 -B -m unittest test_gate_inputs.py`.
3. Run `python3 -B PREFLIGHT.py`.
4. Only if PREFLIGHT_PASS, run `bash RUN_LIVE_GATE.sh` from any directory.
5. Return PASS230_LIVE_RESULT for later adjudication.

Execution does not promote or freeze anything.

Namespace format: an exact slash-prefixed name such as `/brains10/pass230_run1`,
with safe nonempty segments and no trailing slash. Initialization is an atomic
absence-compare plus write. Existing target keys cause HOLD. Use a dedicated,
independently isolated disposable prefix; local string validation does not prove isolation.

The test controls endpoint flags, output, operation timeouts, and read consistency.
Child processes preserve only these ETCDCTL connection options: CACERT, CERT, KEY,
USER, PASSWORD, INSECURE_TRANSPORT, and TLS_SERVER_NAME. Other ETCDCTL defaults are
not inherited into the evidence operations. Credential environment values are not
copied into the result manifest.
No inference about trustworthy provisioning follows from this handling.

CLIENT_REQUEST_CHECK.py is a separate optional local client test. It requires the
documented temporary Python dependencies and an explicit etcdctl executable. It
records requests on loopback and returns a test error for every request. It never
supplies provider authority or a provider-conformance result. The included record
uses official etcdctl v3.6.5 and is scoped to that client binary.

Integrity: GATE_MANIFEST.json hashes every root payload file except itself. The
outer ZIP hash binds the manifest. Shipped test records are records of this
preparation run, not proof of a future live execution. Recompute hashes before use.
