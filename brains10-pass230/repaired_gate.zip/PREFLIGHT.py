import os
import shutil
import subprocess
import sys

from gate_inputs import normalize_namespace


required = ("ETCDCTL_ENDPOINTS", "BRAINS10_ETCD_NAMESPACE")
missing = [name for name in required if not os.environ.get(name, "").strip()]
if missing:
    print("PREFLIGHT_HOLD missing:", ",".join(missing))
    raise SystemExit(2)

endpoints = os.environ["ETCDCTL_ENDPOINTS"]
if endpoints != endpoints.strip():
    print("PREFLIGHT_HOLD malformed endpoints value")
    raise SystemExit(2)

try:
    normalize_namespace(os.environ["BRAINS10_ETCD_NAMESPACE"])
except ValueError as error:
    print("PREFLIGHT_HOLD unsafe namespace:", str(error))
    raise SystemExit(2)

exe = shutil.which("etcdctl")
if not exe:
    print("PREFLIGHT_HOLD etcdctl not found")
    raise SystemExit(2)

try:
    result = subprocess.run([exe, "version"], capture_output=True, text=True, timeout=10)
except (OSError, subprocess.TimeoutExpired):
    print("PREFLIGHT_HOLD etcdctl version failed")
    raise SystemExit(2)
if result.returncode:
    print("PREFLIGHT_HOLD etcdctl version failed")
    raise SystemExit(2)

print("PREFLIGHT_PASS")
print(result.stdout.strip())
