# Prospective Pass 233 evidence guidance — NONCLAIM

This is supplemental preparation, not a reinterpretation or promotion of the original protocol or any historical result.

## Separate the questions being measured

Pass 233's allowed `TESTED_STACK_NO_TORN_STATE_OBSERVED` disposition is a limited atomicity observation. Its ALL_OLD/ALL_NEW population alone cannot establish retention of acknowledged commits. SQLite documents that a transaction may be lost after power failure without corrupting the database under some synchronization modes.

For any future durability assessment, record exact adapter/build identity, stable transition ID, expected old/new state identities, and independently preserved evidence of whether successful commit acknowledgment occurred before the power cut. Unknown ordering stays UNKNOWN. Causal ordering is the requirement; this does not introduce an authoritative wall clock.

| Observed state | Established acknowledgment before cut | Implication |
|---|---|---|
| ALL_OLD | Yes | Acknowledged state was lost: durability failure, even though state is intact. |
| ALL_OLD | No | May be an uncompleted transition; no retention claim follows. |
| ALL_OLD | Unknown | Retention is indeterminate. |
| ALL_NEW | Any | Exact successor survived in this trial; retain acknowledgment scope separately. |
| TORN/CORRUPT | Any | Semantic/integrity failure. |
| INDETERMINATE | Any | Keep in the trial population and report the uncertainty. |

## Artifact completeness and acquisition

The original rule “Missing WAL/SHM ... makes the evidence set incomplete” needs a distinction between **observed absence** and **lost or unrecorded artifacts**. SQLite can checkpoint and remove WAL/SHM on clean final close. An existing WAL is persistent database state and must remain associated with its database copy. The first connection after a crash may begin recovery.

For each DB/WAL/SHM file, record PRESENT_CAPTURED, OBSERVED_ABSENT, or UNKNOWN/UNREADABLE, plus acquisition stage and evidence. Document whether reboot, automatic service startup, filesystem recovery, opening SQLite, or clean closure occurred before capture. Unknown acquisition effects prevent a pristine post-fault-byte claim. Preserve source evidence and perform semantic checks on a working copy where supported. A platform-specific acquisition plan must be validated on the real stack; no universal read-only acquisition recipe is asserted here.

## Prospective completeness

Record the declared trial population and scheduling/randomization procedure before execution. Preserve failed boots, interrupted runs, missing observations, target configuration, actual synchronization settings, data/device placement, and write-cache/power-protection configuration. Do not choose a trial count or acceptable risk threshold without the intended deployment requirement. RESULT_SCHEMA.json in the original is an example record, not an executable JSON Schema validator, and does not itself enforce these fields.

## Research and limits

- https://www.sqlite.org/pragma.html#pragma_synchronous — durability and consistency are distinct; WAL FULL adds commit synchronization.
- https://www.sqlite.org/wal.html — WAL persistence, checkpoint/cleanup, and recovery on reopening.
- The current WAL documentation also identifies version-specific known defects; the actual target build and vendor fixes must be recorded and checked before interpreting a physical campaign.

No hardware, power-loss trial, production adapter, or independently preserved acknowledgment trace was supplied. Physical durability remains HOLD. The original Pass 233 archive is preserved unchanged.
