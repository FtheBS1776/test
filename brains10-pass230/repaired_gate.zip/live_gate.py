import base64
import json
import os
import subprocess
import sys

from gate_inputs import build_init_script, build_txn_script, child_environment, normalize_namespace, txn_outcome


EP = os.environ["ETCDCTL_ENDPOINTS"]
NS = normalize_namespace(os.environ["BRAINS10_ETCD_NAMESPACE"])
HEAD = NS + "/authority/head"
TX = NS + "/authority/tx/pass230"


def ctl(args, stdin=None, output="simple"):
    env = child_environment(os.environ)
    try:
        return subprocess.run(
            ["etcdctl", "--endpoints", EP, "--write-out", output,
             "--command-timeout", "5s", "--dial-timeout", "2s"] + args,
            input=stdin,
            text=True,
            capture_output=True,
            env=env,
            timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        print("HOLD etcdctl execution failed:", type(error).__name__)
        raise SystemExit(2)


def must(result, label):
    if result.returncode:
        if result.stdout:
            print("INCOMPLETE_STDOUT", result.stdout.strip())
        print("HOLD", label, result.stderr.strip())
        raise SystemExit(2)


def get(key, serializable=False):
    args = ["get", key, "--consistency=s" if serializable else "--consistency=l"]
    result = ctl(args, output="json")
    must(result, "get")
    obj = json.loads(result.stdout)
    print("RANGE_JSON", json.dumps({"key": key, "serializable": serializable, "response": obj}, sort_keys=True))
    return obj


def value(obj):
    kvs = obj.get("kvs") or []
    if not kvs:
        return None
    return base64.b64decode(kvs[0]["value"], validate=True).decode("utf-8")


def require_outcome(result, expected, label):
    actual = txn_outcome(result.stdout)
    if actual != expected:
        print("HOLD", label, "expected", expected, "observed", actual)
        raise SystemExit(2)


def main():
    initial = '{"authority_config":"PASS230","digest":"PASS230-G0","generation":0}'
    successor = '{"authority_config":"PASS230","digest":"PASS230-G1","generation":1}'
    receipt_value = "PASS230-TX-1"

    # Absence conditions and setup write are one transaction; no check/write gap.
    result = ctl(["txn"], stdin=build_init_script(HEAD, TX, initial))
    must(result, "initialize")
    print("TXN_INIT", result.stdout.strip())
    require_outcome(result, "SUCCESS", "initialize-target-keys-absent")

    linear = get(HEAD, False)
    serial = get(HEAD, True)
    print("LINEARIZABLE_RANGE_OBSERVED", value(linear) == initial)
    print("SERIALIZABLE_PATH_OBSERVED", value(serial) == initial)

    txn_script = build_txn_script(HEAD, TX, initial, successor, receipt_value)
    txn1 = ctl(["txn"], stdin=txn_script)
    must(txn1, "txn")
    print("TXN1", txn1.stdout.strip())
    require_outcome(txn1, "SUCCESS", "txn-first-outcome")

    after = get(HEAD)
    receipt = get(TX)

    txn2 = ctl(["txn"], stdin=txn_script)
    must(txn2, "txn-replay")
    print("TXN_REPLAY", txn2.stdout.strip())
    require_outcome(txn2, "FAILURE", "txn-replay-outcome")

    after2 = get(HEAD)
    receipt2 = get(TX)

    checks = {
        "linear_read_is_initial": value(linear) == initial,
        "head_is_successor": value(after) == successor,
        "receipt_present": value(receipt) == receipt_value,
        "replay_head_unchanged": value(after2) == successor,
        "replay_receipt_unchanged": value(receipt2) == receipt_value,
    }
    print("CHECKS", json.dumps(checks, sort_keys=True))

    if not all(checks.values()):
        print("LIVE_GATE_DEFECT_OR_INDETERMINATE")
        raise SystemExit(1)

    print("LIVE_GATE_OBSERVATIONS_PASS")


if __name__ == "__main__":
    main()
