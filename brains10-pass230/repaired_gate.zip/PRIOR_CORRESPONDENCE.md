# Correspondence before continuation repair

Scope: Pass 230 client framing, invocation, setup writes, and observation parsing. No provider trust is inferred.

1. L7: incomplete observations cannot earn PASS; exact identity and byte integrity do not establish authority; caller configuration is not independently provisioned trust.
2. L2: preserve transition boundaries and exact inputs; perform absence checks and their write atomically; authority, execution, observation and verification remain distinct.
3. Genie/EXP-010: limit conformance to the actual executable and environment checked, retain incomplete runs, and do not substitute local fixtures for external evidence.
4. Relevant defeated patterns: helper tests hiding incomplete serialization; check-then-write races; ambiguous status parsing; ambient settings changing execution. These are engineering correspondences, not freshly verified historical artifacts.
5. Required checks: complete transaction framing including final delimiter; official client parser acceptance; client invocation with required endpoint configuration; setup conditions and write in one transaction; status read from response header; missing prerequisites and existing result paths remain HOLD.
6. REUSE: the prepared exact-value compare and two-write transaction; L2 atomic compare-and-write; existing output-path preservation.
7. ADAPT: encode etcdctl sections completely, remove child-environment copies of explicit CLI flags, fix output format, and make setup conditional on absent target keys.
8. New authority machinery: none. This is bounded repair of the evidence harness.
9. Mature external domain: etcd CLI grammar and transaction semantics. Internal inspection preceded matching v3.6.5 upstream source research; subsequent client checks validate parsing only.
10. Remaining HOLDs: live provider behavior, endpoint identity/provisioning, isolated namespace ownership, root/custody, physical durability and rollback resistance. No promotion/freeze.

The Pass 231/232 reruns verify supplied local examples only. Pass 233's no-torn-state claim is narrower than retention of acknowledged commits; any durability extension needs acknowledgment chronology and the exact physical stack.

## Pass 233 evidence addendum correspondence, before drafting

L2 transition assurance and EXP-010 prospective chronology require the external acknowledgment/cut ordering to be recorded before interpreting survival. L7 integrity/authority distinctions prevent a valid database digest from proving that an acknowledged state survived. Reuse existing ALL_OLD/ALL_NEW classifications and exact adapter bindings. Adapt collection to record commit acknowledgment, artifact presence/absence, and acquisition effects. No new authority service or wall-clock requirement is introduced; causal ordering is sufficient when established. SQLite's upstream WAL and synchronous documentation supplies the mature-domain research. Physical stack and acquisition-method validation remain external HOLD. Apply the addendum prospectively; do not reinterpret historical receipts.
