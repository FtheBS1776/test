# Adjudication Contract

A later adjudicator must verify result integrity and establish:
- a real external endpoint and isolated namespace were used;
- authority decisions did not use serializable reads;
- exact Compare prevented stale replay;
- the first transaction reported SUCCESS and its replay reported FAILURE;
- successor and transaction identity were written in one Txn success branch;
- retry did not create a second logical transition;
- no local fallback supplied authority.

Allowed dispositions:
CONFORMS_WITHIN_TESTED_SCOPE
DEFECT_FOUND
INDETERMINATE
