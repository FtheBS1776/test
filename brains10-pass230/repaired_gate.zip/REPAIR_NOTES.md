# Pass 230 gate repair — NONCLAIM

Continuation revision 2 supersedes the first repair for future use. It also fixes
the missing final section terminator, duplicated endpoint environment/CLI flags,
output-format ambiguity, and the setup check/write gap. See CONTINUATION_REPORT.md
and CLIENT_REQUEST_RESULT.json for the actual evidence and its scope. Live result
manifests now include the preparation manifest digest as a byte binding only.

The source package's `live_gate.py` supplied the literal words `compare`, `success`, and `failure` to noninteractive `etcdctl txn`. The documented input format expects a compare block, a blank line, a success block, a blank line, then a failure block. The command parser treats `compare` as a compare expression and rejects it. The source package therefore cannot complete its first transaction with the documented CLI.

This repair copy:

- emits documented blank-line-delimited transaction input and quotes keys/values;
- validates namespace segments before using them in etcd keys or transaction input;
- refuses a preexisting result directory instead of recursively deleting it;
- refuses to overwrite the two exact test keys and checks explicit `SUCCESS`/`FAILURE` outcomes;
- adds offline regression tests for these local input and result-path boundaries.

No live etcd run occurred. External endpoint identity, independent provisioning, isolated namespace ownership, rollback resistance, physical durability, and production conformance remain unestablished. Pass 186 remains controlling; this is NONCLAIM and is not promoted or frozen.
